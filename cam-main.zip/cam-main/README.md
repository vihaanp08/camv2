# Cam — card-swap camera

A camera app for one card trick. Hold a playing card up to the phone, and the
screen shows a *different* card. Snap your fingers and it becomes the real one
again.

This is a rewrite. The starting points were the `Cam.ipa` build and
[`morluto/rea`](https://github.com/morluto/rea), the reverse-engineering tool
used to work out what the original did.

---

## What the original was doing

Reverse-engineered from the shipped binary — Swift symbols, strings, and the
linked framework list:

| Piece | Role |
|---|---|
| `CardTracker`, `PlanarTracker`, `GrayImage` | Hand-rolled quad detection on a grayscale pyramid, plus Lucas-Kanade optical flow |
| `Compositor` | Perspective-warps replacement art onto the card, fits a bilinear illumination grid, keeps fingers in front via `isSkin` |
| `FramePipeline` | Runs the preview a few frames behind so the fake is already painted when the card enters |
| `SnapDetector` | Microphone onset detection |
| `VolumeButtons`, `AVCaptureEventInteraction` | Hardware-button triggers |

The design is sound. The reason it falls apart in the dark is what is *absent*
from the binary. Every one of these returned **zero** matches:

```
torch / setTorchMode ......... 0      ← never turns the light on
lowLightBoost ................ 0      ← hardware low-light boost unused
activeMaxExposureDuration .... 0      ← auto-exposure runs unbounded
videoMinFrameDuration ........ 0      ← frame rate free to collapse
VNDetectRectangles ........... 0      ← no Vision detection
```

So in a dark room:

1. **Auto-exposure buys brightness with time.** Frame duration stretches to
   1/15 s or worse, a handheld card smears, and motion blur destroys the corner
   gradients the tracker needs. Blur is much worse than noise here — noise
   buries the signal, blur deletes it.
2. **Frame rate collapses**, and the pipeline was timed in *frames*. Its own
   settings screen says so: *"4 frames is about 0.13 s"*. That is only true at
   30 fps. At 10 fps every delay, smoothing window and timeout silently
   stretches threefold.
3. **No fill light at all**, on a device with a torch, for a subject held at
   arm's length.
4. **Fingers were detected by skin colour.** Under a streetlight or the torch,
   auto-white-balance drags the whole frame's chroma, and at high ISO colour
   noise is the first thing to go. When that test fails the fake card paints
   straight over the performer's fingers.

---

## What this build does differently

### Capture is driven, not left on automatic
- **Exposure is capped** per brightness band (1/60 s down to 1/24 s), forcing
  the sensor to answer with gain rather than integration time.
- **Frame rate is pinned** between 24 and 60 fps, clamped into whatever the
  chosen format actually supports.
- **The torch is used** as fill light, ramped in gently, at the lowest level
  that keeps the card trackable. Off / Auto / On, user's choice.
- **A binned capture format is selected** at startup. Binning combines adjacent
  photosites in hardware — roughly a stop of signal-to-noise, for resolution
  the tracker does not use. Format is chosen *once*, because switching
  `activeFormat` mid-session causes a visible hitch.
- **Video HDR is disabled.** It fuses differently exposed lines, and the
  frame-to-frame variation shows up as overlay shimmer.

### All timing is in seconds
Every filter uses `alpha = 1 - exp(-dt / tau)` against a measured `dt`. A
10 fps dark-room stream behaves exactly like a 60 fps one. This is covered by a
test that drives the same logic at both rates and compares.

### Detection is preprocessed for darkness
Downscale (averaging an NxN block divides noise sigma by N) → temporal frame
averaging → shadow-lifting gamma → **additive** local contrast.

That last choice matters. The textbook move is to divide by a blurred copy, but
that is wrong here: where the blur approaches zero — most of a dark frame — the
quotient explodes and manufactures edges out of sensor noise. Subtraction
degrades gracefully instead.

### Fingers are found by shape, not colour
`VNDetectHumanHandPoseRequest` joints are projected into card space and each
finger bone drawn as a capsule. Colour-blind by construction, so it survives any
colour of light. A luminance-deviation cue backs it up; chroma is not used at
all.

### Nothing is allowed to strobe
`ConfidenceGate` owns the decision to draw. Hysteresis on the confidence
threshold, **coasting** through dropouts shorter than 0.26 s (at high ISO,
confidence rattles rather than failing cleanly), and asymmetric fades — quick
in, slow out. If tracking is genuinely lost the overlay leaves quietly instead
of twitching. Degenerate quads (bow-ties, slivers) are rejected outright before
they can reach the warp.

### The overlay is relit and grained to match
Relighting happens in **linear** light (the `CIContext` is built with a linear
working space), using a trimmed mean so specular glints and noise tails cannot
drag it. Measured frame noise is then applied to the overlay, re-offset every
frame — a clean card face composited into a grainy dark frame reads as pasted on
no matter how good the geometry is.

### Retroactive confidence
While waiting for a card the preview runs ~0.13 s behind live. That buys *future
information about past frames*: when the card first enters, the detector has one
noisy look and reports almost nothing. Running behind lets the pipeline revisit
that entry frame once later frames confirm a card is really there, and accept
its weak detection after the fact. The fake is already painted the instant the
card becomes visible. The buffer is dropped once the overlay is established, so
performing never feels laggy.

---

## Getting it onto an iPhone

The app has to be compiled, and compiling iOS needs Xcode. Pick whichever route
suits the machine you have.

### Route 1 — build in CI, sideload the IPA (no Xcode needed)

This is the route that matches how the original `Cam.ipa` was distributed: an
**unsigned** IPA that a sideloading tool re-signs with your own Apple ID.

Push the repo to GitHub and the workflow in `.github/workflows/ipa.yml` builds
it on a macOS runner:

```sh
git remote add origin git@github.com:<you>/cam.git
git push -u origin main
```

Then either grab the IPA from the run's **Artifacts**, or tag a version to get a
stable download URL you can open on the phone itself:

```sh
git tag v0.1 && git push origin v0.1
```

Install it with **[Sideloadly](https://sideloadly.io)** (Mac/Windows, plug the
phone in, drop in the IPA, sign in with your Apple ID) or **AltStore**.

> With a free Apple ID, sideloaded apps expire after **7 days** and you can have
> three at a time. A paid developer account extends that to a year.

Public repos get free macOS runner minutes; private repos bill macOS at 10x, so
a public repo is cheaper if you don't mind the code being visible.

### Route 2 — Xcode directly (best for iterating)

If you have Xcode and ~40 GB free:

```sh
open CardSwap/CardSwap.xcodeproj
```

Set your signing team (target **CardSwap** → Signing & Capabilities → pick your
Apple ID), plug in the phone, and hit run. No sideloading tool, no 7-day
re-signing dance while you're testing, and you get a debugger and console.

To produce an IPA locally instead: `./scripts/build-ipa.sh`

### Requirements either way

- iPhone on **iOS 17.2+**
- Xcode **16+** to build

> The camera, torch and Vision requests don't exist in the Simulator. This has
> to run on a real device.

## Layout

```
CardSwap/CardSwap/
  Core/            Pure logic, no platform dependencies — all of this is tested
    Tuning.swift              every constant, in seconds
    LowLightController.swift  brightness bands, torch policy, hysteresis
    ConfidenceGate.swift      the anti-strobe gate
    TemporalSmoother.swift    time-based filters
    LightingEstimator.swift   robust relight + noise estimate
    SnapOnsetDetector.swift   snap detection DSP
    QuadGeometry.swift        quads, homography, DLT solver
  Capture/         AVCaptureSession, sensor control, scene metering, microphone
  Vision/          Card detection and the occlusion mask
  Render/          Compositor, card art, diagnostics overlay
  Model/           Pipeline orchestration, settings, view model
  UI/              SwiftUI screens and the Metal preview
tests/main.swift   Test harness for Core/
```

## Tests

`Core/` is deliberately free of platform dependencies so it can be built and
run on the Mac directly:

```sh
swiftc -O -o /tmp/coretests CardSwap/CardSwap/Core/*.swift tests/main.swift && /tmp/coretests
```

52 assertions over 28 groups. The ones that matter most:

- **Torch does not oscillate in closed loop.** Simulates the torch raising the
  luma it is being judged by — the feedback trap — over 30 s. Asserts at most
  one on/off transition.
- **Bands do not flap.** Luma straddling a threshold every frame for 400 frames
  must not reconfigure the pipeline.
- **Band timing is frame-rate independent**, measured at 60 fps vs 10 fps.
- **The gate coasts a brief dropout** without dimming, **releases a real loss**
  fully, and **does not strobe** when confidence rattles across its thresholds.
- **Dark relight gain is stable**: measured spread **0.0050 vs 0.0220** for the
  naive per-frame mean — 4.4× steadier — while still tracking the true level
  (0.113 against an expected 0.11, i.e. genuinely off the clamps).
- **Snaps fire over outdoor rumble** but wind and traffic alone never
  false-trigger, and a sustained tone does not retrigger.
- **Homography** round-trips, inverts, and returns nil for degenerate quads.

### What is *not* verified here

The app has **never been compiled or run** — this machine has no Xcode, so no
iOS SDK and no device. What *was* checked:

- **The entire app type-checks against real iOS framework headers**, with zero
  errors and zero warnings. Command Line Tools ships the macOS SDK, and that
  SDK contains `System/iOSSupport` — the Mac Catalyst variants of UIKit,
  SwiftUI, AVKit, PhotosUI and MetalKit. Targeting `arm64-apple-ios17.2-macabi`
  checks every file against the genuine headers:

  ```sh
  ./scripts/typecheck.sh
  ```

  This caught several real bugs that `swiftc -parse` missed entirely —
  `AVCaptureEventInteraction` living in AVKit rather than AVFoundation, key
  paths into tuples (which Swift does not support), and two sensor-control
  paths that would have locked the capture device for configuration on every
  frame, forever.

- `project.pbxproj` parses and its object graph has no dangling references.

What this still cannot prove: that it *runs*. Type-checking says nothing about
runtime behaviour, and a handful of iOS-only APIs resolve differently under
Catalyst than on a device. Nor are the numbers in `Tuning.swift` measured — they
are reasoned from the optics and the failure modes. The brightness thresholds
and torch levels are the first things to adjust against real scenes, with
diagnostics turned on.

## Controls

Nothing on screen gives the trick away — it looks like a stock camera.

| Action | Does |
|---|---|
| Tap anywhere | Reveals the real card (and focuses, which is what it looks like) |
| Snap your fingers | The same reveal, hands-free |
| Volume / Camera Control button | The same reveal, without touching the screen |
| Two-finger double tap | Arms it again |
| Two-finger long press | Settings |

It also re-arms itself once a card leaves the frame.

Turn on **Settings → Advanced → Show tracking diagnostics** to see the tracked
outline with its live confidence, brightness band and torch level. That is the
fastest way to tell whether a missed reveal was detection, confidence, or the
gate choosing to fade.
